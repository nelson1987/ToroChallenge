﻿using System;

namespace ToroChallenge.Repository
{
    public class ContaCorrenteRepository
    {
    }
}
