﻿using ToroChallenge.TransferenciaContexto.Domain.Commands.Responses;
using ToroChallenge.TransferenciaContexto.Domain.Commands.Requests;
using MediatR;

namespace ToroChallenge.TransferenciaContexto.Domain.Handlers.Contracts
{
    //public interface IRecebimentoTransferenciaHandler : IRequestHandler<RecebeTransferenciaRequest, RecebeTransferenciaResponse>
    //{
    //    //RecebeTransferenciaResponse Handle(RecebeTransferenciaRequest command);
    //}
}
