﻿using System;

namespace ToroChallenge.Repository.Interfaces
{
    public interface IContaCorrenteRepository
    {
    }
}
