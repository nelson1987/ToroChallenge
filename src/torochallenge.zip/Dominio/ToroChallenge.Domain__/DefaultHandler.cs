﻿namespace ToroChallenge.Domain
{
    public class DefaultHandler : Notification
    {
    }
}
