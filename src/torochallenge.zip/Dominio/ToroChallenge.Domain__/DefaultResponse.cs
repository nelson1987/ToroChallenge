﻿namespace ToroChallenge.Domain
{
    public class DefaultResponse
    {
        public Guid Id { get; set; }
        public DateTime Criacao { get; set; }
    }
}
