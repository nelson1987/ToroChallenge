﻿using System;

namespace ToroChallenge.Domain.Queries.Requests
{
    public class BuscaAtivosNegociadosRequest
    {
        public Guid Id { get; set; }
    }
}
