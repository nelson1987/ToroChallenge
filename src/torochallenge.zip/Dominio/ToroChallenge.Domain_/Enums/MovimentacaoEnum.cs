﻿namespace ToroChallenge.Domain.Enums
{
    public enum MovimentacaoEnum
    {
        Credito = 1,
        Debito = 2
    }
}
