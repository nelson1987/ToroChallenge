﻿namespace ToroChallenge.Domain.Enums
{
    public enum TipoMovimentacaoEnum
    {
        Credito = 1,
        Debito = 2
    }
}
