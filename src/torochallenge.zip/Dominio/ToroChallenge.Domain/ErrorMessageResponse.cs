﻿namespace ToroChallenge.Domain
{
    public class ErrorMessageResponse
    {
        public string Propriedade { get; set; }
        public string MensagemErro { get; set; }
    }
}
