﻿using System;

namespace ToroChallenge.PapelContexto.Domain.Queries.Requests
{
    public class BuscaAtivosNegociadosRequest
    {
        public Guid Id { get; set; }
    }
}
